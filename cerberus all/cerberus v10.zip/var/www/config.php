<?php
define('server' , 'localhost');
define('user', 'changeme');
define('db', 'bot');
define('passwd' , 'changeme');
?>
