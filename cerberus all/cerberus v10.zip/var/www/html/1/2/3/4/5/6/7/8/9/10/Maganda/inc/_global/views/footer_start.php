<?php
?>
<script src="<?php echo $dm->assets_folder; ?>/js/dashmix.core.min.js"></script>
<script src="<?php echo $dm->assets_folder; ?>/js/dashmix.app.min.js"></script>
