<?php
?>
</main>
    <?php if(isset($dm->inc_footer) && $dm->inc_footer) { include($dm->inc_footer); } ?>
</div>
