package com.example.mmm.Admin;


import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;


public class ReceiverDeviceAdmin extends DeviceAdminReceiver {

    @Override
    public void onReceive(Context context, Intent intent)
    {
    }
}
