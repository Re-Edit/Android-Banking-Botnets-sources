<?php
define('DEBUG', false);
define('MYSQL_USER', 'user');
define('MYSQL_PASS', '..yourpassword..');
define('MYSQL_DB_NAME', 'database');
define('MAIN_FOLDER', 'gate');

define('PHP_LOG_PATH', '/var/data/www/php_errors.log');
define('APACHE_LOG_PATH', '/var/data/www/apache_error.log');

